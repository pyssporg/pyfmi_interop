---
id: ID-008
title: One published GUID per adapter artifact
summary: The adapter's published GUID is authoritative and its wire model reuses it, so fingerprinting hashes one identity.
date: 2026-11-22
status: accepted
layers: [architecture]
state: 02-architecture/ir.md
artifacts:
  - src/pyfmi_interop/core/adapter.py
  - src/pyfmi_interop/core/adapter_model.py
  - src/pyfmi_interop/core/adapter_render.py
  - docs/breakdown/02-architecture/layers.md
  - docs/breakdown/02-architecture/ir.md
supersedes: []
superseded_by: []
related: []
---

# ID-008: One published GUID per adapter artifact

## Context

The adapter assembled two identities: the published GUID from the
`pyfmi_interfaces` export identity, written to `wire.json` and `model.json`, and
a second name-derived `deterministic_guid` carried by the wire-plane
`ModelDefinition`. The fingerprint hashed the wire model, so it hashed the
second identity while the artifact published the first.

## Decision

The published GUID from `pyfmi_interfaces` is authoritative. The adapter's
wire-plane model carries that same GUID, and the fingerprint hashes it; no
second name-derived GUID is created for an adapter artifact. The published
`wire.json` and `model.json` GUID values do not move. When a caller passes an IR
whose GUID differs, the adapter's `model.json` fingerprint follows the
authoritative published GUID.

## Rationale

One artifact should publish one identity. The FMI description comes from
`pyfmi_interfaces` and is built from the export identity, so a locally derived
second GUID can disagree with the document it accompanies.

## Alternatives Considered

- Make the name-derived IR GUID authoritative and rewrite the published GUID to
  match; rejected because the FMI description still comes from the export
  identity, leaving the packaged artifact inconsistent.
- Keep both GUIDs and document the difference; rejected because the fingerprint
  would keep identifying a value the artifact never publishes.

## Consequences

- Positive: `wire.json`, `model.json`, the wire model, and the fingerprint all
  describe the same identity.
- Negative: an adapter generated from an IR GUID that differed from its export
  identity gets a new `fingerprint` value; no golden-covered artifact changes.

## Verification

The split and identity rule are checked by the full pytest suite, the golden and
determinism assertions, `ruff check src tests`, and `ctest`. Adapter identity was
exercised against a constructed parser-free `Reduction`.

## Review Trigger

Revisit if `pyfmi_interfaces` stops deriving the GUID from the export identity,
or if a consumer needs the name-derived IR GUID to remain visible for an
adapter artifact.
