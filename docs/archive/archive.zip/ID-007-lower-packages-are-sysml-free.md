---
id: ID-007
title: Lower packages are SysML-free
summary: Artifact-family packages generate from an interface model without SysML, one composition layer per family owns ingestion, and the SysML vocabulary is a dependency-free artifact.
date: 2026-11-22
status: accepted
layers: [intent, architecture]
state: 00-intent/intent.md
artifacts:
  - AGENTS.md
  - docs/breakdown/00-intent/intent.md
  - docs/breakdown/02-architecture/layers.md
  - docs/breakdown/06-evolution/suggested/extract-pyssp-sysml-definitions.md
  - docs/breakdown/06-evolution/suggested/rename-pyfmi-sysml2-to-pyfmi-interfaces.md
  - docs/breakdown/06-evolution/suggested/extract-pyfmi-sysml-from-interop.md
  - docs/breakdown/06-evolution/suggested/make-pyfmi-interfaces-parser-free.md
supersedes: []
superseded_by: []
related:
  - ID-005
  - ID-006
---

# ID-007: Lower packages are SysML-free

## Context

Artifact-family packages generated their artifacts from SysML directly: `pyfmi_interop` carried a `sysml/` boundary, the shared FMI layer sat in `pyfmi_sysml2`, and the vocabulary was bundled with the parser.
That coupling made a family package depend on an ingestion stack it does not own, and it left generation parked under a directory that reads as SysML-first — the false signal the owner reported.
External apps that only need the vocabulary had to depend on a parser, and no single composition layer owned the SysML entry for a family.

## Decision

Artifact-family packages generate their artifacts from an interface model, standalone and SysML-free: `pyfmi_interfaces` (renamed from `pyfmi_sysml2`) owns the FMI interface model and emitters, `pyfmi_interop` owns the interop generator, and `pyfmi_rpr` is unaffected because it is already SysML-free.
Exactly one composition layer per artifact family knows SysML: the new repository `pyfmi_sysml` loads through `pycps_sysml2`, reduces to `Reduction`, maps to `ModelSpec`, and generates; SSP keeps `pyssp_sysml2`.
SysML vocabulary is its own artifact: `pyssp_sysml_definitions` carries `PysspCore` and the artifact vocabularies (`PyfmiInterop`, later FMI/SoS), installs for external apps with no Python dependencies, and `pycps_sysml2` depends on it while keeping the parser, IR, and policies.
`pyfmi_interop` loses its `[sysml]` extra, the `--sysml` flag, and the upstream `pyfmi_sysml2` dependency; the SysML entry moves to `pyfmi-sysml`.

## Rationale

A family package should install and test from its own interface contract, not from a dialect stack it does not own; one composition layer per family leaves a single place that knows SysML and a single place to change when the dialect moves.
Vocabulary is data, not parsing: a dependency-free definitions artifact lets external apps read the vocabulary without pulling a parser, while the parser keeps ownership of the IR and policies.
Generating from an interface model makes the wire and facade boundaries testable without SysML and removes the false signal that generation belongs under `sysml/`.

## Alternatives Considered

- Put the FMI SysML layer inside `pyssp_sysml2`; refused because two artifact families would share one repository and one release.
- Keep the definitions bundled with the parser; refused because external apps would have to depend on a parser to read the vocabulary.
- Leave generation parked under `sysml/`; refused because it signals a SysML-first package and hides that the generator consumes an interface model.
- Keep `pyfmi_interop` as the composition layer; refused because the SSP family would then need the FMI package to parse SysML.

## Consequences

- Positive: family packages install and test from their interface contract, and the SysML entry is one composition layer per family instead of a directory inside the generator.
- Positive: the vocabulary ships without a parser, so external apps take the definitions alone; `pyfmi_interop` drops an optional extra, a CLI flag, and an upstream dependency.
- Negative: two new repositories and a migration window for the rename and the extraction; `pyfmi_sysml2` needs a re-export shim until consumers move.
- Migration: four suggested improvements carry the end states — extract the definitions, rename with a shim, extract the composition layer, then make the interface package parser-free.

## Verification

This record is docs-only: the disposition is recorded before any code moves, and each improvement carries its own acceptance.
The archive entry is added with `pb archive add`; `pb registers`, `pb check --strict`, and `pb node-size --strict` run after the intent, `AGENTS.md`, and layer leaves are rewritten.
The known baseline is 24 HARD `pb check` failures; this change must not increase that count, and the node-size gate must stay green.

## Review Trigger

Revisit if a family package needs to parse SysML directly, if an external app needs something the dependency-free vocabulary cannot carry, or if a composition layer starts generating an artifact from anything other than its interface model.
