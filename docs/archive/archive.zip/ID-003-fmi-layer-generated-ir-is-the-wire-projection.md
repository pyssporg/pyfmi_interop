---
id: ID-003
title: The FMI layer is generated, the IR is the wire projection
summary: The adapter FMU takes its FMI C interface, headers and modelDescription from pyfmi_sysml2; pyfmi_interop implements the model hooks and owns the wire plane, with FMI value references and wire field numbers as separate namespaces.
date: 2026-11-19
status: accepted
layers: [intent, architecture]
state: 00-intent/intent.md
artifacts:
  - AGENTS.md
  - docs/architecture.md
  - docs/breakdown/00-intent/intent.md
  - src/pyfmi_interop/psysml2.py
supersedes: []
superseded_by: []
related:
  - ID-001
  - ID-002
---

# ID-003: The FMI layer is generated, the IR is the wire projection

## Context

The repository maintained its own FMI 2.0 facade: `fmi2_cs_api.cpp` with about
650 of 964 lines of generic plumbing, a private copy of the FMI 2.0.5 headers,
and its own `modelDescription.xml` writer. `pyfmi_sysml2` already emits the full
38-function ABI with C linkage, a plain-C per-port payload header, an instance
struct with typed members, a value-reference map and a `void* user_data` seam,
the FMI headers, and the validated model description. Two facades for one ABI
drift, and parameter and per-instance semantics had to be established twice.

## Decision

The adapter FMU takes its FMI C interface, headers and model description
from `pyfmi_sysml2`; `pyfmi_interop` implements the five model hooks and
keeps the wire plane. FMI value references are the generator's zero-based
declaration-order ones, parameters included; wire field numbers are `1..n`
over input and output signals in canonical name order, both in `wire.json`.
`ir.py` is the wire projection, and field number equals value reference ends.

## Rationale

One FMI facade instead of two, one header set instead of two byte-identical
copies, and parameter semantics correct by construction. The hook seam
suffices: `_model_initialize` runs from `fmi2ExitInitializationMode`, after the
master writes parameters, and `user_data` is the per-instance home for codec,
transport and queues. Separate namespaces keep `model_id` stable under
parameter edits.

## Alternatives Considered

- Keep the interop-owned facade and continue duplicating the FMI plumbing.
- Extract a shared facade library both producers import.
- Consume only the generated headers and keep our own entry points.

## Consequences

- Positive: roughly 650 lines of generic FMI code and a duplicate header set
  become deletable; parameters, per-instance state and the model description
  come from the side that already gets them right; the wire plane is unchanged.
- Negative: a real dependency on `pyfmi_sysml2`'s generated-code API, still
  advertised as experimental, so `resolve_system` must be promoted to the
  documented surface. The layers name things differently — the generated
  description uses the composition path for `modelName` and the component for
  `modelIdentifier` — so interop must state which name it ships.
- Known gaps before the legacy facade can be deleted: no
  `DefaultExperiment@stepSize`; no hook at `EnterInitializationMode` and no
  logger or error channel beyond the returned status; string port signals typed
  `const char*` but read as `std::string`; `model.json`-fed models have no
  architecture and keep the legacy layer until retired or converted.
- Refused: a third FMI facade, or reimplementing the ABI inside the wire plane.

## Verification

The generated artifact is the unit under test. The spike ran behind
`fmi_layer="psysml2"`: 187 tests pass, `ctest` 4/4, both serialization variants
build and package, the two-process UDP exchange passes on the new layer, and two
instances of one FMU bind different addresses in one process. `wire.json` from
the new layer carries both `value_reference` and wire `field` per signal, and
`model_id` is unchanged when a parameter default is edited.

## Review Trigger

Revisit if `pyfmi_sysml2` changes its generated-code contract, if a consumer
needs value references and wire field numbers to coincide again, or if the
generated description stops being sufficient for packaging.
