---
id: ID-009
title: Public adapter seam and interop-owned attribute semantics
summary: The adapter facade publishes writer, guard and selection, attribute semantics live in interop, and definitions carry no export policy.
date: 2026-11-22
status: accepted
layers: [architecture, implementation]
state: 02-architecture/attribute-semantics.md
artifacts:
  - src/pyfmi_interop/core/adapter.py
  - src/pyfmi_interop/core/adapter_model.py
  - src/pyfmi_interop/core/adapter_render.py
  - src/pyfmi_interop/core/attributes.py
  - src/pyfmi_interop/core/__init__.py
  - docs/breakdown/02-architecture/attribute-semantics.md
  - docs/breakdown/02-architecture/layers.md
  - docs/breakdown/03-implementation/fmi-facade.md
supersedes: []
superseded_by: []
related:
  - ID-003
  - ID-007
---

# ID-009: Public adapter seam and interop-owned attribute semantics

## Context

`pyfmi_sysml` reached through `pyfmi_interop.core.adapter` for private names
(`_select_component`, `_require_fmi_layer`, `_write`,
`_strip_default_experiment`). The facade kept those names alive only so the
composition layer could import them. The composition layer also owned timing
spelling, the period heuristic, the default step, the type and causality maps,
the identifier rule and the string capacity, duplicating constants and rules
that belong to the interface; and `pyssp_sysml_definitions.load_with_interop`
embedded export-selection policy in a vocabulary package.

## Decision

The adapter facade publishes `write_adapter_tree`, `require_fmi_layer` and
`select_component`, and drops the private re-exports and the
`DefaultExperiment` regex; the writer asks the emitter for
`include_default_experiment=False`. A new `core/attributes.py` owns attribute
semantics, `pyfmi_sysml` only extracts values, and the conditional
`PyfmiInterop` include policy moves out of `pyssp_sysml_definitions`.

## Rationale

A composition layer should depend on a documented contract, not on internals
that exist to keep an import working. Attribute spelling, precedence and FMI
mapping are interface decisions, so they belong beside the IR and must not be
copied per composition layer. A vocabulary package that decides an export unit
has absorbed composition policy it cannot justify.

## Alternatives Considered

- Keep the private re-exports and import them from `pyfmi_sysml`; refused
  because the seam remains private and unowned.
- Keep `_strip_default_experiment` until a later wave; refused because the
  emitter option exists and a post-pass hides the real writer.
- Leave the rules in `pyfmi_sysml` and re-export them; refused because a second
  home drifts and interop would still need the constants.
- Keep a deprecated `load_with_interop` shim in definitions; no consumer was
  found outside the three repositories, so the policy moved outright.

## Consequences

- Positive: the composition layer imports only public names; one home owns
  timing, type, identity and capacity semantics.
- Positive: `pyssp_sysml_definitions` has no loader, parser or artifact policy.
- Negative: the moved tests and docstrings must name the new owner; a caller of
  `pyssp_sysml_definitions.load_with_interop` outside the three repositories
  would need to switch to `pyfmi_sysml`.
- Migration: `pyfmi_sysml` re-exports `load_with_interop`,
  `DEFAULT_STEP_SIZE_S` and `DEFAULT_STRING_CAPACITY`, so its public names stay.

## Verification

The three repositories' suites pass at or above baseline, `ruff` is clean,
`ctest` is 4/4, and the adapter tree generated before and after the change is
byte-identical, including the model description without `DefaultExperiment`.

## Review Trigger

Revisit if a composition layer needs an attribute rule interop cannot express
from plain values, or if an external consumer needs the definitions package to
select an export unit.
