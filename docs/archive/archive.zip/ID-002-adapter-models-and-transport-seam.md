---
id: ID-002
title: Adapter models and registered wire seams
summary: The repository generates adapter models and owns serialization and transport as registered seams, without taking on semantics.
date: 2026-11-19
status: accepted
layers: [intent, architecture]
state: 00-intent/intent.md
artifacts:
  - AGENTS.md
  - docs/architecture.md
  - docs/breakdown/00-intent/intent.md
supersedes: []
superseded_by: []
related:
  - ID-001
---

# ID-002: Adapter models and registered wire seams

## Context

The wire-only remit stopped at the byte format: generating the model that
carries values to and from that format, and selecting a transport, was left to
each consumer. The same part definition already holds names, value references,
causality, port fields, and order, so a consumer rebuilt a shim that the
generator could emit from the one IR.

## Decision

Generate two models from one part definition: the realtime model and an adapter
model that moves values on and off the byte transport, with no equations and no
`user_step`. Own the wire path as two registered seams — serialization with one
schema authority per backend (protobuf canonical, `packed` second), and
transport selected at run time by name (loopback, UDP, TCP) — while framing
stays single-authority and versioned; wire version 2 adds `payload_format`.

## Rationale

Adapter generation belongs beside the IR and the schema or the cross-language
reading is duplicated and drifts. A registered seam keeps one backend live per
name and one framing authority, while endpoints stay deployment data in the
environment or a manifest so an SSP remains portable. The role follows FMI
causality and adds no interpretation.

## Alternatives Considered

- Leave adapter generation to each consumer.
- Add a catalogue of protocol adapters instead of transport backends.
- Fix the serialization backend and transport at compile time.

## Consequences

- Positive: one part definition yields both models; adapter output rides the
  same conformance vectors as the realtime model; transport choice is a
  deployment concern.
- Negative: a second schema emitter and wire version 2 raise maintenance; every
  transport backend must keep the no-interpretation boundary.
- Refused: RPR, DIS, HLA/RTI, DCP, ED-247, and ROS 2 vocabularies and their
  translation; radio or medium models; time management; mission coordination;
  the federation-endpoint role; and a catalogue of protocol adapters.

## Verification

The generated artifact is the unit under test: adapter tests run against the
emitted model and its shared byte vectors at both ends. `pb check --strict` and
`node-size --strict` keep this record, the amended intent, and the architecture
pointer coherent.

## Review Trigger

Revisit if a consumer needs protocol vocabulary translation, a second framing
implementation, or a transport that cannot fit the name registry.
