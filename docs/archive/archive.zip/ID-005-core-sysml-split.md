---
id: ID-005
title: Core/SysML split, one parse, one FMI facade per artifact
summary: The Python layer splits into a SysML-free core and a SysML boundary; ModelSpec and BuildConfig are the public contract, ModelDefinition stays internal, SysML is parsed once, and each artifact owns one FMI facade.
date: 2026-11-20
status: accepted
layers: [intent, architecture]
state: 00-intent/intent.md
artifacts:
  - AGENTS.md
  - docs/architecture.md
  - docs/breakdown/00-intent/intent.md
  - docs/breakdown/02-architecture/layers.md
  - docs/breakdown/02-architecture/ir.md
  - docs/breakdown/02-architecture/codegen.md
  - src/pyfmi_interop/core/__init__.py
  - src/pyfmi_interop/core/spec.py
  - src/pyfmi_interop/core/pipeline.py
  - src/pyfmi_interop/sysml/parse.py
  - src/pyfmi_interop/sysml/generate.py
supersedes: []
superseded_by: []
related:
  - ID-002
  - ID-003
---

# ID-005: Core/SysML split, one parse, one FMI facade per artifact

## Context

The Python layer mixed SysML-free work with ingestion, and `ModelDefinition`
served as both the internal generator input and the caller-facing contract;
the module graph could pull optional SysML packages into paths that did not
need them. The FMI story said one facade, but the realtime core kept its
interop facade while the adapter took the `pyfmi_sysml2` facade, so the wording
hid the artifact split. ID-003 chose the adapter facade; this refactor states
the boundary the code needs.

## Decision

Split `core/` (SysML-free) from `sysml/` (the boundary). `ModelSpec` is the
public interface and `BuildConfig` the generation choices; `ModelDefinition`
is internal. SysML is parsed once: `parse` returns `ParsedModel`, and
`generate_adapter` consumes it without reloading. Each artifact owns one FMI
facade — the core the interop facade, the adapter the `pyfmi_sysml2` one —
so they never share a binary. Old module paths stay re-export-only facades.

## Rationale

A SysML-free core installs, tests, and runs without the optional dialect
packages. Separating the public specification from the internal IR lets the
generator accept a hand-authored `ModelSpec` without publishing its data model,
and keeps `model.json` an internal manifest rather than a new schema. One parse
removes a second source read that could disagree with the first. One facade per
artifact matches what each artifact links, so the ABI and binary boundaries
agree.

## Alternatives Considered

- Keep one module tree and gate SysML imports lazily inside it.
- Publish `ModelDefinition` as the caller-facing contract.
- Keep `generate_model(fmi_layer=...)` as a single entry point for both
  facades.
- Re-parse the SysML source in `generate_adapter` to avoid carrying a handle.

## Consequences

- Positive: the core suite runs without SysML packages; `ModelSpec` +
  `BuildConfig` + `compile_model` give one documented Python path; the single
  parse pins generation to the specification the caller saw; the facade rule
  matches the artifacts.
- Negative: more modules and two documented entry points (`generate_model` for
  the interop facade, `generate_adapter` for the adapter facade). Compatibility
  facades are additional maintenance for one deprecation window.
- Refused: a second public IR schema, a third facade, or a whole-archive link
  of the runtime into the adapter.
- This record supersedes ID-003 in part: the adapter-facade decision stands,
  but its "one FMI facade instead of two" framing becomes one facade per
  artifact.

## Verification

The generated artifact remains the unit under test. The refactor is green:
218 passed and 3 skipped for the full suite, 177 passed under
`pytest -m "not sysml"`, and `ruff check src tests` is clean. Tests live in
`tests/core/` (SysML-free), `tests/sysml/` (marked `sysml`), and
`tests/test_cli.py`, with the shared `tests/conftest.py`; the marker is
declared in `pyproject.toml`.

## Review Trigger

Revisit if a consumer needs `ModelDefinition` as public API, if the
compatibility facades outlive their migration window, or if `pyfmi_sysml2`
changes its generated-code contract.
