---
id: ID-004
title: The adapter is step-free
summary: An adapter executes once per fmi2DoStep and never schedules, so step size leaves its wire identity, its model description and its build inputs; the realtime model keeps the fixed step.
date: 2026-11-19
status: accepted
layers: [intent, architecture]
state: 00-intent/intent.md
artifacts:
  - src/pyfmi_interop/wire/codec.py
  - src/pyfmi_interop/ir.py
  - src/pyfmi_interop/psysml2.py
  - runtime/src/wire.cpp
  - docs/wire.md
supersedes: []
superseded_by: []
related:
  - ID-002
  - ID-003
---

# ID-004: The adapter is step-free

## Context

An adapter moves values once per `fmi2DoStep` and ignores the master's
communication step; it has no equations and no scheduler, and nothing gates a
signal on its declared rate. Only the realtime model schedules at a fixed step.
The adapter nevertheless hashed step size into `model_id`, declared
`DefaultExperiment` in its model description, and required `--step-size` to
build — so changing a preferred cadence invalidated every peer.

## Decision

The adapter is step-free: `model_id` hashes the model name and the ordered
`(wire field, data type)` records only, under hash domain v2; adapters emit no
`DefaultExperiment`; step size is optional for adapter generation; declared
rates are validated against the slowest declared rate rather than a base step.
The realtime model keeps its fixed step, its scheduler and its experiment.

## Rationale

Cadence belongs to the master. Two adapters with the same interface are
wire-compatible at any cadence, so a scheduling preference must not enter the
wire identity. Keeping `DefaultExperiment` as an advisory hint earns nothing and
implies the adapter has a preferred step it does not have.

## Alternatives Considered

- Keep step size in the wire identity and accept peer invalidation.
- Emit `DefaultExperiment` as a hint for tooling.
- Require one step size for both generated models.

## Consequences

- Positive: an adapter's identity survives cadence edits; its XML states only
  what is true; adapter builds no longer need a scheduling argument.
- Negative: `model_id` changes once more, on the same day the namespaces split;
  peers must rebuild once. Adapter `wire.json` and `model.json` still carry
  `step_size_s` because `pyfmi_rpr` reads it and requires it positive, so the
  key is a compatibility artifact until that consumer migrates.
- Refused: a per-signal cadence enforced inside the adapter.

## Verification

The generated artifact is the unit under test. The adapter's
`modelDescription.xml` contains no `DefaultExperiment` while the realtime
model's does; editing a step size or a declared rate leaves `model_id`
unchanged; a rate that is not an integer multiple of the slowest declared rate
still fails generation; both serialization variants build without `--step-size`.
192 tests pass and `ctest` is 4/4.

## Review Trigger

Drop the residual `step_size_s` from the adapter descriptor and from the
`load_model` default once `pyfmi_rpr` no longer reads it.
