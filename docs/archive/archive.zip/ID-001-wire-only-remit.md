---
id: ID-001
title: Wire-only remit
summary: The repository owns one versioned byte contract for the model interface and nothing above it.
date: 2026-11-19
status: accepted
layers: [intent]
state: 00-intent/intent.md
artifacts:
  - README.md
  - docs/breakdown/00-intent/intent.md
  - docs/breakdown/README.md
  - docs/breakdown/06-evolution/roadmap.md
supersedes: []
superseded_by: []
related: []
---

# ID-001: Wire-only remit

## Context

The 0.2.0 scope was a federation endpoint with a pluggable adapter catalogue:
HLA, DIS, DCP, ROS 2, and ED-247 bindings behind `PYFMI_INTEROP_ENABLE_*`.
Every adapter shipped unavailable, three protocol submodules were pinned but
never built into a working binding, and the checkout reached about 1 GB.
The payload, framing, and cross-language contract the project needed did not
exist.

## Decision

Adopt bytes as the whole remit: the model interface travels as one versioned
protobuf payload, and this repository owns that schema plus the framing around
it — length prefix, CRC32, and format version — with a Python end and a C++
end. Semantics, transport, time, and mission coordination are not ours.

## Rationale

A wire contract is small, testable, and one job: one schema, one frame, two
ends, and shared byte vectors decide correctness. The previous scope produced
unavailable adapters, never-built protocol trees, and a checkout too large to
clone casually, while nothing consumed the federation endpoint it promised.

## Alternatives Considered

- Keep the adapter catalogue and fund one real adapter.
- Keep adapters as optional add-ons beside the wire contract.
- Move the wire contract into a separate repository.

## Consequences

- Positive: one versioned contract with two ends; CI proves it with byte
  vectors; the checkout drops the protocol submodules.
- Negative: the federation-endpoint role and every protocol binding are gone;
  a consumer needing HLA, DIS, DCP, ROS 2, or ED-247 must bind elsewhere.
- Removal anticipated for the next unit: `src/pyfmi_interop/adapters.py`,
  `runtime/src/adapters/*`, `cmake/adapters.cmake`, all
  `PYFMI_INTEROP_ENABLE_*` options, the
  `third_party/{OpenRTI,DCPLib,ED247_LIBRARY}` submodules with their
  `.gitmodules` entries, `docs/adapters.md` replaced by `docs/wire.md`, and the
  `adapters` CLI verb replaced by `transports`.

## Verification

The wire-format work proves the schema round trip at both ends with shared
byte vectors and removes the adapter surface listed above.

## Review Trigger

Revisit if a consumer needs semantics, time management, or a protocol binding
inside this repository, or if the wire schema needs a breaking version.
